<p align="center">
    <img width="400" src="./nvm-logo-color-avatar.png" alt="logo">
</p>

# ⚡Vite + Electron



## How to use

- In the project folder:
  ```bash
  # install dependencies
  yarn # npm install

  # run in developer mode
  yarn dev # npm run dev

  # build
  yarn build # npm run build
  ```