export type Nullable<T> = T | null

export type Voidable<T> = T | null | undefined
