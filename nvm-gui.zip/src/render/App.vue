<script setup lang="ts"></script>

<template>
  <RouterView></RouterView>
</template>

<style></style>
